from py2neo import Graph, Node, Relationship
from py2neo.bulk import create_nodes, create_relationships, merge_nodes
import pandas as pd


# [x] Connect to Neo4j
#       [x] Insert Job Descriptions
#       [x] Insert Annotations
#       [x] Create Relationships
#       [x] Create Recommendation Simple
#       [] Create Recommendation Complex
#       [] Searching Capability i.e ml jobs


# Connection to Neo4j
graph = Graph("bolt://localhost:7687", auth=("neo4j", "root"))

# Testing Connection
graph.run("UNWIND range(1, 3) AS n RETURN n, n * n as n_sq")

# Insert Job Descriptions
# What format should they be in?
#           - Dataframe?
#           - Should have JD's and the corresponding ids for it
#           [] For example here import the data scientist cluster 4 which has the curated ids and the job descriptions
#                   - Ideally the job descriptions should be from the original dataset
#                   [] Need to join the data and get the original jds for no identation issues when trying to
#                   - disply on the webiste

# jobDesDf = pd.read_csv("H:/Thesis/Output_Data/cluster_all_4.csv", sep=";")
jobDesDf = pd.read_csv("H:/Thesis/Output_Data/cluster_all_5.csv", sep=";")
jobDesDf.rename(columns={"job.listingId.long": 'jobId'}, inplace=True)
# [] Insert Job Descriptions
# Use this new code to test and see if the node return shows which property
create_nodes(tx=graph.auto(), data=jobDesDf.to_dict('records'), labels=['JD'])
graph.nodes.match("JD").count()

#       [] Insert Annotations
# [] Need to load first just the nodes with some small id i.e. the annotation as a skill
#
kwDf = pd.read_csv("H:/Thesis/Output_Data/kwDf.csv", sep=";")
records = list()

kwd = kwDf[['skill']].drop_duplicates()
for index, row in kwd.iterrows():
    print(row[0])
    tx = graph.begin()
    # node = Node("skills", skill=[row[0]])
    node = Node("skills", skill=row[0])
    tx.merge(node, primary_label="skills", primary_key="skill")
    graph.commit(tx)

graph.nodes.match("JD").count()
graph.nodes.match("skills").count()
# merge_nodes(tx=graph.auto(), data=kwDf.to_dict('records'), labels=['Skills'], merge_key=keys)
# graph.nodes.match("Skills").count()

jdNodes = graph.nodes.match("JD").all()
# skillNodes = graph.nodes.match("skills").all()

for node in jdNodes:
    tx = graph.begin()
    # print(node['jobId'])
    skills = kwDf[kwDf['id'] == str(node['jobId'])]
    # print(skills)
    for item, row in skills.iterrows():
        # print(row[1])
        skNode = graph.nodes.match("skills", skill=row[1]).first()
        # print(skNode)
        ab = Relationship(skNode, "SKILLOF", node)
        tx.create(ab)
    graph.commit(tx)


# MATCH (j:JD {jobId: 3407021927})-[:CONSISTS]->(skills)<-[:CONSISTS]-(otherGroup)
# RETURN otherGroup.`header.jobTitle`,
# 	   COUNT(skills) AS tsopicsInCommon,
#        COLLECT(skills.skill) As tsopics
# ORDER BY tsopicsInCommon DESC
# LIMIT 100

# MATCH (j:JD {jobId: 3407021927})<-[:SKILLOF]-(skills)-[:SKILLOF]->(otherGroup)
# RETURN otherGroup.`header.jobTitle`,otherGroup.jobId,
# 	   COUNT(skills) AS tsopicsInCommon,
#        COLLECT(skills.skill) As tsopics
# ORDER BY tsopicsInCommon DESC
# LIMIT 100

