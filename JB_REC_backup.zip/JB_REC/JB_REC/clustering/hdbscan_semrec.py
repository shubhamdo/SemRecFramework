# [] Pull Data from Neo4J
#       [] Filter the records
#       [] Create CSR Matrix for the records
#       [] Do Feature Selection
#       [] Cluster data
#       [] Give Random Values in each cluster and create balanced data set
#               [] Positive data
#               [] Negative data
import itertools
from itertools import combinations

import hdbscan
import pandas as pd
from numpy.random import uniform
from sklearn.feature_extraction.text import CountVectorizer
from JB_REC.graph.neoconnection import connectToNeo4J


def vectorizeData(text):
    vec = CountVectorizer()
    X = vec.fit_transform(text)
    return X


def concatenateStrings(df):
    # title, description = df['header.jobTitle'], df['job.description']
    # cnString = title + " " + description
    df['test'] = ""
    for index, row in df.iterrows():
        title = row[0]
        description = row[1]
        cnString = title + " " + description
        df.at[index, 'test'] = cnString

    return df


def makePositiveSamples():
    pass


def makeNegativeSamples():
    pass


if __name__ == "__main__":
    # Connect to DB
    graph = connectToNeo4J()
    graph.nodes.match("JD").count()

    # Retrieve Data from Neo4J
    jdNodes = graph.nodes.match("JD").all()

    # Convert to Dataframe
    df = pd.read_csv("H:/Thesis/Output_Data/cluster_all.csv", sep=";")
    df = df[['job.listingId.long', 'header.jobTitle', 'job.description']]
    df = df.set_index('job.listingId.long')
    # df = df.sample(n=50000)
    # df = df.iloc[:4000, :]


    # df = concatenateStrings(df)
    # newDf = pd.Series()
    # df['test'] = df['header.jobTitle'].apply(concatenateStrings, args=(df['job.description'],))

    # [x] Get all records
    # [x] Get Random 10000 Records
    # [x] Filter Records in original records
    # [x] Convert into vectors
    # [x] Cluster
    # [] Create Positive
    # [] Create Negative Samples Based on Positive Sample Size and Computation

    dataSize = df.shape[0]
    while dataSize >= 0:
        nor = 10000
        if dataSize <= 10000:
            nor = dataSize
        # [x] Get Random 10000 Records
        df_sample = df.sample(n=nor)
        # [x] Filter Records in original records
        df = df[~df.index.isin(df_sample.index)]
        dataSize = df.shape[0]
        if dataSize == 0:
            break
        # [x] Convert into vectors
        csrMat = vectorizeData(df_sample['header.jobTitle'])

        # [x] Cluster
        clusterer = hdbscan.HDBSCAN(min_cluster_size=200)
        clusterer.fit_predict(csrMat)
        df_sample['cluster'] = clusterer.labels_.tolist()
        df_sample = df_sample[df_sample['cluster'] != -1]
        # [x] Create Positive
        clusters = set(df_sample['cluster'].tolist())
        for cluster in clusters:
            currentCluster = df_sample[df_sample['cluster'] == cluster]

            if currentCluster.shape[0] > 100:
                currentCluster = currentCluster.sample(n=100)

            otherCluster = df_sample[df_sample['cluster'] != cluster]  # Required for Negative Records
            # otherCluster = df_sample[~df_sample.index.isin(currentCluster.index)]  # Required for Negative Records
            lenOfCurrentCluster = currentCluster.shape[0]
            lenOfOtherCluster = otherCluster.shape[0]
            if lenOfCurrentCluster > lenOfOtherCluster:
                lenOfCurrentCluster = lenOfOtherCluster
            print("The current cluster is: {} and length of cluster is: {} ".format(cluster, lenOfCurrentCluster))
            otherCluster = otherCluster.sample(n=lenOfCurrentCluster)  # Gets num of records as the positive

            currentJobDescriptions = currentCluster['job.description']
            otherJobDescriptions = otherCluster['job.description']

            for combination in combinations(otherJobDescriptions, 2):
                # print(combination)
                record = dict()
                record['inputA'] = combination[0].strip()
                record['inputB'] = combination[1].strip()
                record['similarity'] = uniform(0.1, 0.4)
                negativeRecords = [record]
                negativeRecords = pd.DataFrame(negativeRecords)
                negativeRecords = negativeRecords.drop_duplicates()
                negativeRecords.to_csv("H:/Thesis/Output_Data/TrainingData/Negative_TrainingData.csv", mode="a",
                                       sep=";", index=False, header=False)

            # otherJobDescriptions = ["a", "b", "c", "d"]
            # currentJobDescriptions = [1, 4, 9]
            # permut = itertools.permutations(
            #     otherJobDescriptions, len(otherJobDescriptions))
            # for comb in permut:
            #     zipped = zip(comb, currentJobDescriptions)
            #     for each in zipped:
            #         record = dict()
            #         record['inputA'] = each[0]
            #         record['inputB'] = each[1]
            #         record['similarity'] = uniform(0.1, 0.3)
            #         negativeRecords = [record]
            #         negativeRecords = pd.DataFrame(negativeRecords)
            #         negativeRecords = negativeRecords.drop_duplicates()
            #         negativeRecords.to_csv("H:/Thesis/Output_Data/Negative_TrainingData.csv", mode="a", sep=";",
            #                                header=False)
            # print(negativeRecords)

            for combination in combinations(currentJobDescriptions, 2):
                record = dict()
                record['inputA'] = combination[0].strip()
                record['inputB'] = combination[1].strip()
                record['similarity'] = uniform(0.7, 1.0)
                positiveRecords = [record]
                positiveRecords = pd.DataFrame(positiveRecords)
                positiveRecords = positiveRecords.drop_duplicates()
                positiveRecords.to_csv("H:/Thesis/Output_Data/TrainingData/Positive_TrainingData.csv", mode="a",
                                       sep=";", index=False, header=False)

    # [] Create Negative Samples Based on Positive Sample Size and Computation

    # [x] Current Cluster
    # [x] Other Clusters
    # [x] 1 Records from Current Cluster, Sample one from other cluster
    # [x] Filter the other cluster with the sample taken
    # [x] Store the records with random 0.1 to 0.4 values

    # [] Import Training Data
    # [] Create Input Samples for Training the Semantic Model i.e SBERT
    # [] Create Code for Running the Training
    # [] Find Evaluation Code
    # [] Save the model
    # [] Write Inference Code
    # [] Import Model
    # [] Pass the Records
    # [] Get Cosin value
    # []

# initialize lists
