import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import sklearn.datasets as data
import pandas as pd

"""sns.set_context('poster')
sns.set_style('white')
sns.set_color_codes()
plot_kwds = {'alpha' : 0.5, 's' : 80, 'linewidths':0}

moons, _ = data.make_moons(n_samples=50, noise=0.05)
blobs, _ = data.make_blobs(n_samples=50, centers=[(-0.75,2.25), (1.0, 2.0)], cluster_std=0.25)
test_data = np.vstack([moons, blobs])
plt.scatter(test_data.T[0], test_data.T[1], color='b', **plot_kwds)

import hdbscan

clusterer = hdbscan.HDBSCAN(min_cluster_size=5, gen_min_span_tree=True)
clusterer.fit(test_data)"""

df = pd.read_csv("H:/Thesis/Output_Data/glassdoor_clean.csv", delimiter=";")
df = df[df.notna()]
df["job.listingId.long"] = df["job.listingId.long"].astype(np.int64)
# df.set_index("job.listingId.long", inplace=True)
df = df[["job.listingId.long","header.jobTitle",
         "header.location",
         "job.description",
         "job.jobSource",
         "map.country",
         "map.employerName",
         "map.location",
         "overview.industry",
         "overview.sector",
         "overview.size",
         "overview.description"]]
df.drop_duplicates(["job.listingId.long"], inplace=True)

# df = df[["header.jobTitle"]]
df = df[pd.notnull(df["header.jobTitle"])]
# jt = jt.iloc[:50000]

from sklearn.feature_extraction.text import TfidfVectorizer

vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(df["header.jobTitle"])
print(vectorizer.get_feature_names())
print(X.shape)
x = df["header.jobTitle"].tolist()
import hdbscan
from sklearn.datasets import make_blobs

# data, _ = make_blobs(1000)
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA

kmean_indices = KMeans(n_clusters=10, random_state=0).fit_predict(X)
df["clusters"] = kmean_indices.tolist()

# df_final = pd.DataFrame()
# df_final["clusters"] = pd.Series(kmean_indices.tolist())
# df_final["id"] = df.index
# df_final["header.jobTitle"] = df["header.jobTitle"]
# df_final["job.listingId.long"] = df["job.listingId.long"]
# df_final = df_final[pd.notnull(df_final["job.listingId.long"])]
# df_final["job.listingId.long"] = df_final["job.listingId.long"].astype(np.int64)
# jt_fil = df_final["clusters"] == 1
# df_final[jt_fil]

df.drop_duplicates(["job.listingId.long"], inplace=True)
df.to_csv("H:/Thesis/Output_Data/cluster_all.csv", sep=";", index=False)
"""pca = PCA(n_components=2)
scatter_plot_points = pca.fit_transform(X.toarray())

colors = ["r", "b", "c", "y", "m", ]

x_axis = [o[0] for o in scatter_plot_points]
y_axis = [o[1] for o in scatter_plot_points]
fig, ax = plt.subplots(figsize=(20,10))

ax.scatter(x_axis, y_axis, c=[d for d in kmean_indices])

for i, txt in enumerate(x):
    ax.annotate(txt, (x_axis[i], y_axis[i]))
"""
