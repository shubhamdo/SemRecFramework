import pandas as pd

df = pd.read_csv("H:/Thesis/Output_Data/cluster_all.csv", delimiter=";")
df = df[df.notna()]


df = df[['job.listingId.long', 'header.jobTitle', 'job.description', 'clusters']]


for row in range(10):
    df_filter = df["clusters"] == row
    df1 = df[df_filter]
    df1.to_csv(f"H:/Thesis/Output_Data/cluster_all_{row}.csv", sep=";", index=False)
