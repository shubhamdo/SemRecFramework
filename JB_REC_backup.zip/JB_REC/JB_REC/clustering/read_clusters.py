from time import sleep
import pandas as pd
import numpy as np
from nltk.corpus import stopwords
import ast
from sklearn.feature_extraction.text import TfidfVectorizer

# Extra Stop Words
stwrd = ""
with open(file="H:/Thesis/Input_Data/stop_words_english.txt", encoding='utf-8') as f:
    stwrd = f.readline()

stwrd = ast.literal_eval(stwrd)
# Merge Both stop words from nltk and external
stop_words = set(stopwords.words("english")).union(set(stwrd))

# Import Cluster Number - 4 Data Scientist Records
df = pd.read_csv("H:/Thesis/Output_Data/cluster_all_4.csv", delimiter=";")
df = df[df.notna()]

# Remove Duplicates
df.drop_duplicates(inplace=True)
df = df[df['job.description'].notna()]

for eachrow in df['job.description']:
    if "skillsknowledge" in eachrow:
        print(eachrow)


# Remove Stop Words
def remove_stop_words(sentence):
    lw = sentence.split(sep=" ")
    lw = [word for word in lw if not word in stop_words]
    s = ' '.join([w for w in lw])
    return s


df['job.description.sw'] = df['job.description'].apply(remove_stop_words)

vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(df['job.description.sw'])
ds = vectorizer.vocabulary_

words = pd.DataFrame(list(ds.items()), columns=['words', 'id'])

words.sort_values(by=['id'], inplace=True)


words.to_csv("H:/Thesis/Input_Data/words.csv", sep=";", index=False)
