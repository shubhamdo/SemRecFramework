# [] Pull Data from Neo4J
#       [] Filter the records
#       [] Create CSR Matrix for the records
#       [] Do Feature Selection
#       [] Cluster data
#       [] Give Random Values in each cluster and create balanced data set
#               [] Positive data
#               [] Negative data
import hdbscan
import pandas as pd
from sklearn import metrics
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.cluster import KMeans
from sklearn.cluster import DBSCAN
from sklearn.cluster import OPTICS
from sklearn import metrics
from sklearn.metrics import pairwise_distances
from sklearn.preprocessing import StandardScaler
import hdbscan
from sklearn.datasets import make_blobs
from JB_REC.graph.neoconnection import connectToNeo4J


def vectorizeData(text):
    vec = CountVectorizer()
    # vec = TfidfVectorizer()
    X = vec.fit_transform(text)
    return X


def get_kmeans(data, csr, n_clusters=3):
    """ Do kmeans clustering and return clustered data """
    kmeans = KMeans(n_clusters=n_clusters, init="k-means++", n_init=10, max_iter=300)
    # vals = data.iloc[:, 0:].values
    y_pred = kmeans.fit_predict(csr)
    data["cluster"] = y_pred
    return data, kmeans.inertia_


def concatenateStrings(df):
    # title, description = df['header.jobTitle'], df['job.description']
    # cnString = title + " " + description
    df['test'] = ""
    for index, row in df.iterrows():
        title = row[0]
        description = row[1]
        cnString = title + " " + description
        df.at[index, 'test'] = cnString

    return df


def makePositiveSamples():
    pass


def makeNegativeSamples():
    pass


def get_hdbscan(data, csr, min_cluster_size=4):
    clusterer = hdbscan.HDBSCAN(min_cluster_size=min_cluster_size)
    y_pred = clusterer.fit_predict(csrMat)
    data["cluster"] = y_pred.tolist()

    # hdb = hdbscan.HDBSCAN(min_cluster_size=min_cluster_size, gen_min_span_tree=True)
    # vals = data.iloc[:, 0:].values
    # y_pred = hdb.fit_predict(StandardScaler().fit_transform(vals))
    # data["cluster"] = y_pred
    return data, clusterer


def plot_clustering(data, k=None, vars=None):
    """ Plot the clustered data. """
    if vars == None:
        cols = list(data.columns)
    else:
        vars.append('cluster')
        vars = set(vars)
        vars = list(vars)
        cols = vars
    g = sns.pairplot(data[cols], hue='cluster', diag_kind='hist')
    if not k == None:
        plt.subplots_adjust(top=0.9)
        g.fig.suptitle(k + 2)
        g.fig.tight_layout()
    plt.subplots_adjust(left=0.05, bottom=0.05)
    plt.show()


if __name__ == "__main__":
    # Connect to DB
    graph = connectToNeo4J()
    graph.nodes.match("JD").count()

    # Retrieve Data from Neo4J
    jdNodes = graph.nodes.match("JD").all()

    # Convert to Dataframe
    df = pd.read_csv("H:/Thesis/Output_Data/cluster_all.csv", sep=";")
    df = df[['job.listingId.long', 'header.jobTitle', 'job.description']]
    df = df.set_index('job.listingId.long')
    # df = df.sample(n=50000)
    # df = df.iloc[:4000, :]

    df_sample = df.sample(n=10000)
    df_1 = df[df.index.isin(df_sample.index)].copy()
    df_2 = df_1.copy()
    csrMat = vectorizeData(df_sample['header.jobTitle'])
    # csrMat = vectorizeData(df_sample['job.description'])
    # [x] Cluster

    kmeans = []
    elbow = []
    calinskis = []
    silhouettes = []
    number_clusters = []
    i = 1
    for i in range(10):
        temp1, temp2 = get_kmeans(df_1, csrMat, i + 2)
        # kmeans.append(data.merge(temp1['cluster']))
        elbow.append(temp2)
        cal = metrics.calinski_harabasz_score(csrMat.toarray(), df_1['cluster'])
        silhouet = metrics.silhouette_score(csrMat.toarray(), df_1['cluster'])

        calinskis.append(cal)
        silhouettes.append(silhouet)
        number_clusters.append(i + 2)
        print(cal, silhouet)

plt.plot(elbow, 'ro-', label="Elbow")
plt.title("KMeans Elbow")
plt.show()

plt.plot(number_clusters, calinskis, 'ro-', label="KMeans Ralinski Harabasz Score")
plt.title("KMeans Calinski Harabasz Score")
plt.xlabel("number of clusters")
plt.show()

plt.plot(number_clusters, silhouettes, 'ro-', label="KMeans Silhouette Score")
plt.title("KMeans Silhouette Score")
plt.xlabel("number of clusters")
plt.show()


plot_clustering(df_1)
